package budget;

public enum Type {
    Food, Clothes, Entertainment, Other, All
}
