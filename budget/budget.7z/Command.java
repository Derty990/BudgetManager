package budget;

public interface Command {
    void execute();
}
